from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QComboBox, QLabel, QHBoxLayout, QPushButton, QCheckBox, QWidget, QMessageBox

from app.ui_qt.dialogs.workspace_dialogs import ColumnViewDialog
from app.ui_qt.widgets.lead_table import LeadTableView


PRESET_VIEWS = {
    "All columns": None,
    "Research": ["First Name", "Last Name", "Company Name", "Company Website", "Job Title", "Industry",
                 "Country", "Phone Number", "Prospect LinkedIn Link", "Business Email ID"],
    "Email Finding": ["First Name", "Last Name", "Company Name", "Company Website", "Business Email ID",
                      "Email Status", "Prospect LinkedIn Link", "QA Status", "Primary Reason"],
    "QA Review": ["First Name", "Last Name", "Company Name", "Business Email ID", "Job Title", "Country",
                  "Company Website", "QA Status", "Primary Reason", "QA Name", "Audited Date", "Comment"],
}
IDENTITY_COLUMNS = {"First Name", "Last Name", "Company Name"}


class WorkspaceTools:
    def build_workspace_selector(self, root):
        row = QHBoxLayout()
        row.addWidget(QLabel("Workspace"))
        self.workspace_selector = QComboBox()
        self.workspace_selector.setMinimumWidth(250)
        self.workspace_selector.setMaximumWidth(430)
        self.workspace_selector.setAccessibleName("Campaign workspace")
        row.addWidget(self.workspace_selector)
        label = QLabel("Each campaign keeps its own leads and reference lists.")
        label.setObjectName("muted")
        label.setWordWrap(True)
        row.addWidget(label, 1)
        root.addLayout(row)
        self.update_workspaces()
        self.workspace_selector.currentIndexChanged.connect(lambda: self.workspace_requested.emit(self.workspace_selector.currentData() or ""))

    def update_workspaces(self):
        selected = self.controller.active_campaign.campaign_id if self.controller.active_campaign else ""
        self.workspace_selector.blockSignals(True)
        self.workspace_selector.clear()
        self.workspace_selector.addItem("General workspace", "")
        for profile in self.controller.campaign_store.list():
            self.workspace_selector.addItem(f"{profile.campaign_id} — {profile.campaign_name}", profile.campaign_id)
        self.workspace_selector.setCurrentIndex(max(0, self.workspace_selector.findData(selected)))
        self.workspace_selector.blockSignals(False)

    def build_view_controls(self, toolbar):
        row = QHBoxLayout()
        row.addWidget(QLabel("View"))
        self.view_selector = QComboBox()
        self.custom_views = self.controller.settings_service.get("lead_column_views", {})
        self.view_selector.addItems([*PRESET_VIEWS, *[name for name in self.custom_views if name not in PRESET_VIEWS]])
        self.view_selector.setMinimumWidth(145)
        row.addWidget(self.view_selector)
        save_view = QPushButton("Save view…"); save_view.clicked.connect(self.save_column_view)
        row.addWidget(save_view)
        self.freeze_identity = QCheckBox("Freeze Name / Company")
        row.addWidget(self.freeze_identity)
        row.addStretch()
        self.undo_button = QPushButton("Undo")
        self.undo_button.setToolTip("Undo the last cell edit, paste or clear · Ctrl+Z")
        self.redo_button = QPushButton("Redo")
        self.redo_button.setToolTip("Redo the last undone edit · Ctrl+Y")
        self.undo_button.clicked.connect(self.undo_edit)
        self.redo_button.clicked.connect(self.redo_edit)
        row.addWidget(self.undo_button); row.addWidget(self.redo_button)
        toolbar.addLayout(row)
        self.filter_hint = QLabel("Use the dropdown in any column heading to filter.")
        self.filter_hint.setWordWrap(True)
        self.filter_hint.setObjectName("muted")
        toolbar.addWidget(self.filter_hint)
        self._applying_view = False
        self._view_widths = self.controller.settings_service.get("lead_column_widths", {})

    def build_table_pair(self, root):
        self.frozen_table = LeadTableView()
        self.frozen_table.setModel(self.proxy)
        self.frozen_table.setSelectionModel(self.table.selectionModel())
        self.frozen_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        for table in (self.table, self.frozen_table):
            table.request_filter.connect(self.open_filter)
            table.request_find.connect(self.search.setFocus)
            table.request_save.connect(self.save_requested)
            table.request_validate.connect(self.validate_requested)
            table.request_undo.connect(self.undo_edit)
            table.request_redo.connect(self.redo_edit)
            table.data_mutated.connect(self.refresh)
            table.horizontalHeader().sectionResized.connect(self._column_resized)
        self.frozen_table.verticalScrollBar().valueChanged.connect(self.table.verticalScrollBar().setValue)
        self.table.verticalScrollBar().valueChanged.connect(self.frozen_table.verticalScrollBar().setValue)
        self.frozen_table.horizontalHeader().sortIndicatorChanged.connect(self.table.horizontalHeader().setSortIndicator)
        self.table.horizontalHeader().sortIndicatorChanged.connect(self.frozen_table.horizontalHeader().setSortIndicator)
        holder = QWidget(); layout = QHBoxLayout(holder); layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(0)
        layout.addWidget(self.frozen_table); layout.addWidget(self.table, 1)
        root.addWidget(holder, 1)
        self.model.changed.connect(self.cells_changed)
        self.proxy.filters_changed.connect(self.update_filter_display)
        self.width_timer = QTimer(self); self.width_timer.setSingleShot(True); self.width_timer.setInterval(350)
        self.width_timer.timeout.connect(lambda: self.controller.settings_service.set("lead_column_widths", self._view_widths))
        self.view_selector.currentTextChanged.connect(self.change_column_view)
        self.freeze_identity.toggled.connect(self.apply_column_view)
        preferred = self.controller.settings_service.get("lead_last_view", "All columns")
        self.view_selector.setCurrentText(preferred if self.view_selector.findText(preferred) >= 0 else "All columns")
        self.change_column_view(self.view_selector.currentText())

    def change_column_view(self, name):
        freeze = self.custom_views.get(name, {}).get("freeze", name != "All columns")
        self.freeze_identity.blockSignals(True); self.freeze_identity.setChecked(freeze); self.freeze_identity.blockSignals(False)
        self.controller.settings_service.set("lead_last_view", name)
        self.apply_column_view()

    def apply_column_view(self, *_):
        if not hasattr(self, "frozen_table"):
            return
        self._applying_view = True
        try:
            name = self.view_selector.currentText()
            headers = self.controller.data_manager.headers
            columns = PRESET_VIEWS.get(name, self.custom_views.get(name, {}).get("columns"))
            visible = set(headers if columns is None else columns)
            if self.freeze_identity.isChecked():
                visible.update(IDENTITY_COLUMNS)
            pinned = visible & IDENTITY_COLUMNS if self.freeze_identity.isChecked() else set()
            for index, header in enumerate(headers):
                self.table.setColumnHidden(index, header not in visible or header in pinned)
                self.frozen_table.setColumnHidden(index, header not in pinned)
                width = int(self._view_widths.get(name, {}).get(header, 120 if header in IDENTITY_COLUMNS else 170))
                self.table.setColumnWidth(index, width)
                self.frozen_table.setColumnWidth(index, width)
            self.frozen_table.setVisible(bool(pinned))
            self.table.verticalHeader().setVisible(not pinned)
            self._resize_frozen()
            self.update_filter_display()
        finally:
            self._applying_view = False

    def _resize_frozen(self):
        width = self.frozen_table.verticalHeader().width() + 4
        width += sum(self.frozen_table.columnWidth(i) for i in range(self.model.columnCount()) if not self.frozen_table.isColumnHidden(i))
        self.frozen_table.setFixedWidth(width)

    def _column_resized(self, column, old, width):
        if self._applying_view or not hasattr(self, "frozen_table"):
            return
        self._applying_view = True
        try:
            self.table.setColumnWidth(column, width); self.frozen_table.setColumnWidth(column, width)
            name = self.controller.data_manager.headers[column]
            self._view_widths.setdefault(self.view_selector.currentText(), {})[name] = width
            self._resize_frozen()
            self.width_timer.start()
        finally:
            self._applying_view = False

    def save_column_view(self):
        selected = [name for i, name in enumerate(self.controller.data_manager.headers)
                    if not self.table.isColumnHidden(i) or not self.frozen_table.isColumnHidden(i)]
        dialog = ColumnViewDialog(self, self.controller.data_manager.headers, selected, self.freeze_identity.isChecked())
        if not dialog.exec(): return
        name = dialog.name.text().strip()
        if name in PRESET_VIEWS:
            QMessageBox.information(self, "Choose another name", "The built-in views are kept as defaults. Choose a name for your custom view.")
            return
        self.custom_views[name] = {"columns": dialog.selected_columns(), "freeze": dialog.freeze.isChecked()}
        self.controller.settings_service.set("lead_column_views", self.custom_views)
        if self.view_selector.findText(name) < 0: self.view_selector.addItem(name)
        self.view_selector.setCurrentText(name)
        self.change_column_view(name)

    def update_filter_display(self):
        if not hasattr(self, "frozen_table"):
            return
        columns = set(self.proxy.column_filters) | set(self.proxy.column_conditions)
        for table in (self.table, self.frozen_table):
            table.horizontalHeader().filtered_columns = columns
            table.horizontalHeader().viewport().update()
        names = [self.controller.data_manager.headers[i] for i in sorted(columns) if i < self.model.columnCount()]
        text = "Column filters: " + ", ".join(names) if names else "Use the dropdown in any column heading to filter."
        self.filter_hint.setText(text)
        count = len(self.controller.data_manager.records)
        visible = len(self.visible_rows())
        self.count_label.setText(f"{visible:,} of {count:,} leads")
        self.clear_filters_btn.setEnabled(bool(columns or self.proxy.search_text or self.proxy.status_filter != "All"))

    def visible_rows(self):
        count = len(self.controller.data_manager.records)
        return [index for row in range(self.proxy.rowCount()) if (index := self.proxy.mapToSource(self.proxy.index(row, 0)).row()) < count]

    def selected_rows(self):
        count = len(self.controller.data_manager.records)
        return sorted({self.proxy.mapToSource(index).row() for index in self.table.selectionModel().selectedIndexes()
                       if self.proxy.mapToSource(index).row() < count})

    def undo_edit(self):
        index = self.proxy.mapToSource(self.table.currentIndex())
        if self.controller.undo_edit():
            self.refresh()
            self.restore_cell(index.row(), index.column())

    def redo_edit(self):
        index = self.proxy.mapToSource(self.table.currentIndex())
        if self.controller.redo_edit():
            self.refresh()
            self.restore_cell(index.row(), index.column())

    def cells_changed(self):
        # Keep the active editor and keyboard position during ordinary cell edits.
        self.update_filter_display()
        self.undo_button.setEnabled(bool(self.controller.history.undo_stack))
        self.redo_button.setEnabled(bool(self.controller.history.redo_stack))
        self.empty_hint.setVisible(not self.controller.data_manager.records)

    def restore_cell(self, row, column):
        if row < 0 or column < 0: return
        index = self.proxy.mapFromSource(self.model.index(row, column))
        if index.isValid():
            table = self.frozen_table if not self.frozen_table.isColumnHidden(column) else self.table
            table.setCurrentIndex(index)

    def focus_source_cell(self, row, field=None):
        headers = self.controller.data_manager.headers
        column = headers.index(field) if field in headers else headers.index("QA Status")
        table = self.frozen_table if not self.frozen_table.isColumnHidden(column) else self.table
        if table.isColumnHidden(column):
            table.setColumnHidden(column, False)
        index = self.proxy.mapFromSource(self.model.index(row, column))
        if not index.isValid():
            self.clear_filters()
            index = self.proxy.mapFromSource(self.model.index(row, column))
        table.setCurrentIndex(index); table.scrollTo(index); table.setFocus()
