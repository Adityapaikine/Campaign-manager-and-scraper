from PySide6.QtCore import Qt, QRect, QPoint, Signal
from PySide6.QtGui import QColor, QPolygon
from PySide6.QtWidgets import QHeaderView, QStyleOptionHeader, QStyle


class FilterHeader(QHeaderView):
    filter_requested = Signal(int)

    def __init__(self, parent=None):
        super().__init__(Qt.Orientation.Horizontal, parent)
        self.filtered_columns = set()
        self.setSectionsClickable(True)
        self.setMinimumSectionSize(65)

    def paintSection(self, painter, rect, logical):
        if not rect.isValid():
            return
        option = QStyleOptionHeader()
        self.initStyleOption(option)
        option.rect = rect
        option.section = logical
        option.textAlignment = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        text = str(self.model().headerData(logical, self.orientation(), Qt.ItemDataRole.DisplayRole) or "")
        option.text = self.fontMetrics().elidedText(text, Qt.TextElideMode.ElideRight, max(15, rect.width() - 45))
        option.sortIndicator = QStyleOptionHeader.SortIndicator.None_
        painter.save()
        self.style().drawControl(QStyle.ControlElement.CE_Header, option, painter, self)
        button = QRect(rect.right() - 23, rect.top() + 3, 21, rect.height() - 6)
        active = logical in self.filtered_columns
        painter.setPen(QColor("#0D827D" if active else "#71819B"))
        painter.setBrush(QColor("#DCF2EF" if active else "#EAF0F7"))
        painter.drawRoundedRect(button.adjusted(0, 1, -1, -1), 3, 3)
        x, y = button.center().x(), button.center().y()
        painter.setBrush(QColor("#0D827D" if active else "#71819B"))
        if active:
            painter.drawPolygon(QPolygon([QPoint(x-5,y-4), QPoint(x+5,y-4), QPoint(x+1,y), QPoint(x+1,y+5), QPoint(x-1,y+4), QPoint(x-1,y)]))
        else:
            painter.drawPolygon(QPolygon([QPoint(x-4,y-2), QPoint(x+4,y-2), QPoint(x,y+3)]))
        if self.isSortIndicatorShown() and logical == self.sortIndicatorSection():
            painter.drawText(QRect(rect.right()-39, rect.top(), 14, rect.height()), Qt.AlignmentFlag.AlignCenter,
                             "↑" if self.sortIndicatorOrder() == Qt.SortOrder.AscendingOrder else "↓")
        painter.restore()

    def mousePressEvent(self, event):
        logical = self.logicalIndexAt(event.position().toPoint())
        if logical >= 0 and event.button() == Qt.MouseButton.LeftButton:
            right = self.sectionViewportPosition(logical) + self.sectionSize(logical)
            if event.position().x() >= right - 25:
                self.filter_requested.emit(logical)
                event.accept()
                return
        super().mousePressEvent(event)
