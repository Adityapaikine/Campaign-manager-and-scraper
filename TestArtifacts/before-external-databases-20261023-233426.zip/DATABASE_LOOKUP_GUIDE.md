# Populate leads from the local database

The application uses its existing local SQLite database. No server, credentials, or internet connection is required.

- Database: `Data/LeadManager/cache/lead_manager.sqlite3`
- Reference table: `lead_reference`
- Headers: the same 42 standard lead headers, plus any custom headers present when data is copied.
- All saved workspaces are copied into this shared reference table on initial setup. Their existing worksheet files are preserved. Blank entry rows are excluded. Reopening the application does not repeat the initial copy.

## Populate a worksheet

1. Open **Leads Workspace** and import, paste, or enter the leads to enrich.
2. Click **Populate from database** beside **Import leads**.
3. Choose **Selected leads**, **Visible leads**, or **All leads in this workspace**. If rows are selected, Selected leads is the default; otherwise, Visible leads is the default.
4. Check the columns to populate. This chooser opens every time, with no remembered column selections.
5. Leave **Replace existing values** unchecked to fill only empty cells. Check it to replace values in the selected columns.
6. Click **Populate**. Results show how many cells and leads changed. **Show Details** lists skipped-cell counts and the first 200 missing-key, missing-match, empty-source, or conflicting-value cases.

| Fields | Match key |
| --- | --- |
| Business Email ID, Job Title, Job Level, Job Function, Address, City, State, Zip Code, Address Link, Country, Phone Number, Phone Number Link | Prospect LinkedIn Link |
| Company Name, Company Website, Industry, Company Size, Industry Link, Revenue, Revenue Link, SIC Code, NAICS Code, SIC/NAICS Code Link | Company Website |

Matching ignores HTTP versus HTTPS, `www`, trailing URL slashes, and query strings. Company websites match on the full hostname after removing `www`; distinct subdomains stay separate. Prospect matching accepts LinkedIn `/in/` profile links. Missing or invalid keys do not match.

**Company Website is both a lookup key and an optional destination column.** A blank company website cannot be populated using this lookup. When a website already exists, replacement can copy the matching saved URL spelling, such as `https://www.example.com/`.

## How values are handled

- Only checked destination columns are populated. The existing validation workflow also marks affected leads and related duplicates **Needs validation**.
- Empty source values never erase existing worksheet values.
- Multiple matching reference rows are allowed. Each selected field is populated only when all its nonempty saved values agree, ignoring letter case. Different values are reported as a conflict; no arbitrary first row wins. Other nonconflicting fields can still be filled.
- Postal, SIC, and NAICS codes are stored as text so existing leading zeros are retained.
- Sorting and filtering preserve the underlying lead identities.
- Population is one **Undo / Redo** operation. Use **Ctrl+Z** or **Ctrl+Y** during the current editing session. Successful changes are saved to the workspace; history is session-only, as with other edits.
- Lookup reads the reference database without changing it. An activity entry records the selected fields and counts.

## Add more reference data later

Use the workspace's **…** menu → **Add current leads to reference database…**. This copies the complete current workspace with all columns after showing its lead count. Identical full rows and blank rows are skipped; existing database rows are preserved. If new rows disagree with older values for a matching key, subsequent population reports those fields as conflicts.

For direct SQLite maintenance, quote headers containing spaces or punctuation, for example `SELECT "Business Email ID" FROM lead_reference`. Direct SQL edits to the table are used on the next lookup. Resolve conflicting source values in the reference table before retrying those fields. The small `lead_reference_meta` table only records that initial workspace copying has completed.

The new reference table is independent of TAL and suppression lists. Their validation rules and existing imports, exports, scraping, and email-finding operations remain in place.
