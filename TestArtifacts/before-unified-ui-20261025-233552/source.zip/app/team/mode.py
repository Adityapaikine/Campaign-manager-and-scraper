"""Explicit cutover marker; no database access is needed to select the launcher."""
from pathlib import Path


def shared_mode_requested(database,arguments,environment):
    return '--research' not in arguments and ('--team' in arguments or bool(environment.get('LEAD_TEAM_SERVER')) or Path(database).with_suffix('.team-mode').exists())


def enable_shared_mode(database):
    marker=Path(database).with_suffix('.team-mode')
    marker.write_text('Shared records are authoritative. Launch Team Workspace. Local research uses a separate data folder.\n',encoding='utf-8')
