"""Authenticated desktop shell reusing the existing Lead Workspace grid."""
import json
from types import SimpleNamespace
from PySide6.QtCore import Qt,QTimer,QThreadPool,QItemSelection,QItemSelectionModel
from PySide6.QtWidgets import (QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QLabel,QListWidget,QStackedWidget,
    QTabBar,QToolButton,QMenu,QMessageBox,QInputDialog,QTableWidget,QTableWidgetItem,QHeaderView,QComboBox,QLineEdit,QSplitter,QProgressBar)
from app.ui_qt.team_controller import TeamController
from app.ui_qt.pages.leads_page import LeadsPage
from app.ui_qt.dialogs.team_dialogs import TeamTask,CampaignPicker,FormDialog,RowsDialog
from app.ui_qt.widgets.campaign_charts import CampaignCharts
from app.core.campaign_dashboard import CampaignProgress,parse_date
from app.ui_qt.qt_theme import build_stylesheet
from app.ui_qt.team_actions import TeamActions
from app.ui_qt.team_admin import TeamAdmin

class TeamWindow(TeamActions,TeamAdmin,QMainWindow):
    def __init__(self,client):
        super().__init__(); self.client=client; self.controller=TeamController(client)
        self.controller.error_callback=lambda msg:QMessageBox.information(self,'Lead Workspace',msg)
        self.busy=False; self._closing=False; self.campaign=None; self.sheet_rows=[]; self.offset=0; self.total=0; self.view='mine'; self.save_conflict=False
        self.setWindowTitle('Lead Workspace · '+client.user['full_name']); self.resize(1540,940); self.setMinimumSize(1120,720)
        self.setStyleSheet(build_stylesheet('Professional Blue',False)); self._build()
        self.autosave=QTimer(self); self.autosave.timeout.connect(self.auto_save); self.autosave.start(30000)
        self.poll=QTimer(self); self.poll.timeout.connect(self.poll_notifications); self.poll.start(45000)
        self.run(lambda:(self.client.call('campaigns'),self.client.call('preferences')),self.initialize,'Loading your workspace…')

    def _build(self):
        holder=QWidget(); holder.setObjectName('appRoot'); self.setCentralWidget(holder); outer=QVBoxLayout(holder)
        top=QHBoxLayout(); name=QLabel('Lead Workspace'); name.setObjectName('sectionTitle'); top.addWidget(name)
        self.campaign_badge=QLabel('No campaign selected'); self.campaign_badge.setTextFormat(Qt.TextFormat.PlainText); top.addWidget(self.campaign_badge,1)
        choose=QPushButton('Select Campaign'); choose.clicked.connect(self.select_campaign); top.addWidget(choose)
        self.notification_button=QPushButton('Notifications'); self.notification_button.clicked.connect(self.show_notifications); top.addWidget(self.notification_button)
        account=QToolButton(); account.setText(self.client.user['full_name']); account.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu=QMenu(account); menu.addAction('Open local research tools…',self.open_local_research); menu.addAction('Change password…',self.change_password); menu.addAction('Sign out',self.sign_out); account.setMenu(menu); top.addWidget(account); outer.addLayout(top)
        body=QHBoxLayout(); outer.addLayout(body,1); self.nav=QListWidget(); self.nav.setFixedWidth(180); body.addWidget(self.nav)
        self.stack=QStackedWidget(); body.addWidget(self.stack,1)
        self.workspace=QWidget(); layout=QVBoxLayout(self.workspace); layout.setContentsMargins(0,0,0,0)
        sheetbar=QHBoxLayout(); self.tabs=QTabBar(); self.tabs.setExpanding(False); self.tabs.setMovable(False); self.tabs.currentChanged.connect(self.switch_sheet)
        sheetbar.addWidget(self.tabs,1); plus=QPushButton('+'); plus.setFixedWidth(32); plus.clicked.connect(self.new_sheet); sheetbar.addWidget(plus)
        sheet_menu=QToolButton(); sheet_menu.setText('Sheets'); sheet_menu.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu=QMenu(sheet_menu)
        for label,fn in [('Rename sheet',self.rename_sheet),('Duplicate sheet',self.duplicate_sheet),('Delete sheet',self.delete_sheet)]: menu.addAction(label,fn)
        sheet_menu.setMenu(menu); sheetbar.addWidget(sheet_menu); layout.addLayout(sheetbar)
        self.leads=LeadsPage(self.controller,compact=True); layout.addWidget(self.leads,1)
        operations=QHBoxLayout(); self.commit_button=QPushButton('Review & commit valid rows'); self.commit_button.setObjectName('primaryButton'); self.commit_button.clicked.connect(self.commit_draft)
        operations.addWidget(self.commit_button)
        self.workflow_buttons=[]
        for label,fn in [('Save',self.save),('Find / replace',self.find_replace),('Workflow',self.workflow_action),('Assign',self.assign_leads),('Push to Department',self.transfer_leads),('Return for rework',self.return_rework),('View History',self.show_history)]:
            button=QPushButton(label); button.clicked.connect(fn); operations.addWidget(button)
            if label not in ('Save','Find / replace'):self.workflow_buttons.append((label,button)); button.hide()
        extras=QToolButton(); extras.setText('More'); extras.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup); menu=QMenu(extras)
        for label,fn in [('Comments',self.comments),('Transfer history',self.transfer_history),('Archive selected',self.archive_selected),('Restore selected',self.restore_selected),('Assign historical owner',self.assign_historical),('Save recovery draft',self.recover_draft),('Export validation errors',self.export_errors),('Save filter view',self.save_filter_view),('Load filter view',self.load_filter_view)]: menu.addAction(label,fn)
        extras.setMenu(menu); operations.addStretch(1); operations.addWidget(extras); layout.addLayout(operations)
        pagebar=QHBoxLayout(); self.previous=QPushButton('Previous'); self.next=QPushButton('Next'); self.previous.clicked.connect(lambda:self.page(-1)); self.next.clicked.connect(lambda:self.page(1))
        self.paging=QLabel(); self.query=QLineEdit(); self.query.setPlaceholderText('Search shared records in this campaign…'); self.query.returnPressed.connect(self.refresh_records)
        pagebar.addWidget(self.query,1); pagebar.addWidget(self.previous); pagebar.addWidget(self.paging); pagebar.addWidget(self.next); layout.addLayout(pagebar)
        self.stack.addWidget(self.workspace)
        self.dashboard=self._dashboard(); self.stack.addWidget(self.dashboard)
        self.admin_page=self.build_admin_page(); self.stack.addWidget(self.admin_page)
        self.report_page=self.build_report_page(); self.stack.addWidget(self.report_page)
        self.items=['Dashboard','My Worksheets','My Leads']
        role=self.client.user['role']
        if role in ('Super User','Department Manager','Team Lead'): self.items+=['Team Leads','Incoming Leads','Pending Assignment','Transferred Leads']
        if role in ('Super User','Department Manager'): self.items+=['Department Leads']
        self.items+=['Reports']
        if role=='Super User': self.items+=['Archived Leads','Administration','Activity Logs']
        self.nav.addItems(self.items); self.nav.currentTextChanged.connect(self.navigate)
        self.status=QLabel('Connecting…'); self.statusBar().addWidget(self.status,1)
        self.job_progress=QProgressBar(); self.job_progress.setRange(0,0); self.job_progress.setMaximumWidth(130); self.job_progress.hide(); self.statusBar().addPermanentWidget(self.job_progress)
        self.cancel_read=QPushButton('Cancel'); self.cancel_read.hide(); self.cancel_read.setToolTip('Discard this read/preview when it returns. No campaign write is canceled.'); self.statusBar().addPermanentWidget(self.cancel_read)
        self.cancel_read.clicked.connect(self.cancel_preview)
        self._wire_grid()

    def _wire_grid(self):
        p=self.leads
        # Campaign selection is already persistent in the shared shell header.
        p.workspace_label.hide(); p.workspace_selector.hide()
        p._filter_widgets=(p.search,p.status,p.clear_filters_btn)
        for action in p.more_menu.actions():
            if action.text().startswith('Add current leads to reference'):action.setVisible(False)
        p.empty_hint.setText('No leads yet. Open a personal worksheet to import, paste or enter leads, then validate and commit.')
        p.import_requested.connect(self.import_leads); p.export_requested.connect(self.export_leads); p.save_requested.connect(self.save)
        p.paste_requested.connect(p.table.paste_clipboard); p.new_requested.connect(self.new_sheet)
        p.validate_requested.connect(self.validate); p.validate_selected_requested.connect(lambda:self.validate(selected=True)); p.validate_edited_requested.connect(self.validate)
        p.recheck_requested.connect(lambda row:self.validate(indices=[row])); p.validation_summary_requested.connect(self.show_validation_summary)
        p.workspace_requested.connect(lambda cid:self.select_campaign_id(cid)); p.columns_added.connect(self.mark_dirty); p.model.changed.connect(self.mark_dirty)
        p.load_tal_requested.connect(lambda:self.configure_reference('tal')); p.load_suppression_requested.connect(lambda:self.configure_reference('suppression')); p.manage_references_requested.connect(self.show_campaign_configuration)
        p.populate_requested.connect(self.populate_reference); p.database_connection_requested.connect(self.configure_reference_database); p.add_to_database_requested.connect(self.add_reference_data)
        p.find_emails_requested.connect(self.find_emails)
        for table in (p.table,p.frozen_table):
            table.horizontalHeader().setSectionsMovable(True)
            table.authorized_copy=self.copy_authorized
        p.search.setToolTip('Filters the currently loaded page or personal draft. Use the shared search below for all accessible campaign records.')

    def open_local_research(self):
        import os,sys,subprocess
        from pathlib import Path
        root=Path(__file__).resolve().parents[2]
        python=Path(sys.executable).with_name('pythonw.exe')
        if not python.exists():python=Path(sys.executable)
        subprocess.Popen([str(python),str(root/'run.pyw'),'--research'],cwd=root,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)

    def _dashboard(self):
        page=QWidget(); layout=QVBoxLayout(page); title=QLabel('Campaign dashboard'); title.setObjectName('pageTitle'); layout.addWidget(title)
        bar=QHBoxLayout(); select=QPushButton('Select Campaign'); select.clicked.connect(self.select_campaign); bar.addWidget(select)
        refresh=QPushButton('Refresh'); refresh.clicked.connect(self.refresh_dashboard); bar.addWidget(refresh); bar.addStretch(1); layout.addLayout(bar)
        headers=['Campaign name','CID','Team Lead','Total allocation','Start date','End date','Total leads','Qualified leads','Disqualified leads','Delivered leads','Remaining to deliver','Average leads per day','Status']
        self.campaign_table=QTableWidget(0,len(headers)); self.campaign_table.setHorizontalHeaderLabels(headers); self.campaign_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.campaign_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows); self.campaign_table.setAlternatingRowColors(True)
        self.campaign_table.itemDoubleClicked.connect(lambda item:self.select_campaign_id(self.campaign_table.item(item.row(),1).text()))
        split=QSplitter(Qt.Orientation.Vertical); split.addWidget(self.campaign_table); self.charts=CampaignCharts(self.controller); split.addWidget(self.charts); split.setSizes([350,270]); layout.addWidget(split,1)
        note=QLabel('Calendar-day target includes both dates and rounds up. Shared lead totals count each Lead ID once; only authorized records contribute.'); note.setWordWrap(True); note.setObjectName('muted'); layout.addWidget(note)
        return page

    def run(self,fn,done=None,message='Working…',cancellable=False):
        if self.busy or self._closing:return
        operation={'canceled':False}; self.active_operation=operation
        self.job_progress.show(); self.cancel_read.setVisible(cancellable); self.cancel_read.setEnabled(True)
        self.busy=True; self.status.setText(message); self.leads.set_data_busy(True); self.nav.setEnabled(False); self.tabs.setEnabled(False)
        task=TeamTask(fn); self.task=task
        def finish(value):
            self.job_progress.hide(); self.cancel_read.hide()
            self.busy=False; self.leads.set_data_busy(False); self.nav.setEnabled(True); self.tabs.setEnabled(True); self.status.setText('Ready')
            if operation['canceled']:self.status.setText('Canceled · results discarded; no draft changes applied.'); return
            if done:
                try: done(value)
                except Exception as exc: self.failed(str(exc))
        def failure(msg):
            self.job_progress.hide(); self.cancel_read.hide()
            self.busy=False; self.leads.set_data_busy(False); self.nav.setEnabled(True); self.tabs.setEnabled(True); self.failed(msg)
        task.signals.result.connect(finish); task.signals.error.connect(failure); QThreadPool.globalInstance().start(task)

    def cancel_preview(self):
        self.active_operation['canceled']=True; self.cancel_read.setEnabled(False)
        self.status.setText('Cancel requested. Waiting for the current read to finish; its results will be discarded.')

    def failed(self,message):
        if self._closing:return
        if self.controller.dirty:
            self.save_conflict=True
            message+='\nYour unsaved edits remain open. Use More > Save recovery draft to preserve them in a separate private sheet, or retry Save after the connection is restored.'
        self.status.setText(message); QMessageBox.warning(self,'Lead Workspace',message)
        if not self.client.token:
            self.leads.set_data_busy(True); self.status.setText('Session expired. Close this window and sign in again. Unsaved values remain in memory only.')

    def initialize(self,result):
        campaigns,prefs=result; self.controller.campaigns=campaigns; self.controller.settings_service.values=prefs
        self.leads._view_widths=prefs.get('lead_column_widths',{})
        self.leads.update_workspaces(); self.nav.blockSignals(True); self.nav.setCurrentRow(0); self.nav.blockSignals(False)
        cid=prefs.get('last_campaign')
        campaign=next((c for c in campaigns if c['campaign_id']==cid),campaigns[0] if campaigns else None)
        if campaign:self.select_campaign_id(campaign['campaign_id'])
        else:self.status.setText('No assigned campaigns. A Super User can create a campaign and assign your account.')

    def select_campaign(self):
        if self.busy:return
        dialog=CampaignPicker(self,self.controller.campaigns)
        if dialog.exec(): self.select_campaign_id(dialog.selected()['campaign_id'])

    def select_campaign_id(self,cid):
        if self.busy or not cid:return
        campaign=next((c for c in self.controller.campaigns if c['campaign_id']==cid),None)
        if not campaign:return
        def switch():
            self.campaign=campaign; self.controller.active_campaign=SimpleNamespace(**campaign)
            self.controller.settings_service.set('last_campaign',cid)
            self.campaign_badge.setText(campaign['campaign_name']+' · '+cid); self.leads.update_workspaces()
            self.run(lambda:(self.client.call('sheets',campaign_id=cid),self.client.call('field_access',campaign_id=cid)),self.campaign_loaded,'Opening campaign…')
        self.with_saved(switch)

    def campaign_loaded(self,result):
        sheets,permissions=result; self.controller.field_permissions=permissions; self.sheet_rows=sheets; self.rebuild_tabs()
        current=self.nav.currentItem().text() if self.nav.currentItem() else 'Dashboard'
        if current=='Dashboard':self.stack.setCurrentWidget(self.dashboard); self.refresh_dashboard()
        elif current!='My Worksheets':self.navigate(current)
        elif sheets:self.load_sheet(next((s['id'] for s in sheets if s['id']==self.controller.settings_service.get('last_sheet_'+self.campaign['campaign_id'])),sheets[0]['id']))
        else:self.new_sheet(default=True)

    def navigate(self,name):
        if self.busy:return
        def go():
            if name=='Dashboard': self.stack.setCurrentWidget(self.dashboard); self.refresh_dashboard()
            elif name=='Administration': self.stack.setCurrentWidget(self.admin_page); self.refresh_admin()
            elif name=='Activity Logs': self.run(lambda:self.client.call('audit'),lambda rows:RowsDialog(self,'Activity logs',rows).exec())
            elif name=='Reports': self.stack.setCurrentWidget(self.report_page); self.refresh_report()
            else:
                self.stack.setCurrentWidget(self.workspace)
                draft=name=='My Worksheets'; self.tabs.setVisible(draft); self.commit_button.setVisible(draft)
                for label,button in self.workflow_buttons:button.setVisible(not draft and not(label in ('Assign','Push to Department') and self.client.user['role']=='Employee'))
                for widget in (self.previous,self.next,self.query,self.paging): widget.setVisible(not draft)
                if not self.campaign: self.select_campaign(); return
                if draft:
                    if self.sheet_rows:self.load_sheet(self.sheet_rows[max(0,self.tabs.currentIndex())]['id'])
                    else:self.new_sheet(default=True)
                else:
                    self.view={'My Leads':'mine','Incoming Leads':'incoming','Pending Assignment':'pending_assignment','Transferred Leads':'transferred','Archived Leads':'archived'}.get(name,'all')
                    self.offset=0; self.refresh_records()
        self.with_saved(go)

    def with_saved(self,fn):
        self.remember_view()
        if self.controller.dirty:self.save(after=fn)
        else:fn()

    def remember_view(self):
        if not self.campaign:return
        p=self.leads; headers=self.controller.data_manager.headers; header=p.table.horizontalHeader()
        settings={'search':p.search.text(),'status':p.status.currentText(),'view':p.view_selector.currentText(),
          'sort':headers[p.proxy.sortColumn()] if 0<=p.proxy.sortColumn()<len(headers) else None,'descending':p.proxy.sortOrder()==Qt.SortOrder.DescendingOrder,
          'filters':{headers[c]:list(v) for c,v in p.proxy.column_filters.items() if c<len(headers)},
          'conditions':{headers[c]:v for c,v in p.proxy.column_conditions.items() if c<len(headers)},
          'order':[headers[header.logicalIndex(i)] for i in range(len(headers))]}
        self.controller.settings_service.set('workspace_view_'+self.controller.workspace_key,settings)

    def restore_view(self):
        p=self.leads; headers=self.controller.data_manager.headers
        prefs=self.controller.settings_service; saved=prefs.get('workspace_view_'+self.controller.workspace_key,{})
        p.custom_views=prefs.get('lead_column_views',{})
        for name in p.custom_views:
            if p.view_selector.findText(name)<0:p.view_selector.addItem(name)
        name=saved.get('view',prefs.get('lead_last_view','All columns')); p.view_selector.setCurrentText(name)
        p.search.setText(saved.get('search','')); p.status.setCurrentText(saved.get('status','All'))
        for field,values in saved.get('filters',{}).items():
            if field in headers:p.proxy.set_column_filter(headers.index(field),set(values))
        for field,rule in saved.get('conditions',{}).items():
            if field in headers:p.proxy.set_condition(headers.index(field),rule)
        if saved.get('sort') in headers:p.proxy.sort(headers.index(saved['sort']),Qt.SortOrder.DescendingOrder if saved.get('descending') else Qt.SortOrder.AscendingOrder)
        for pane in (p.table,p.frozen_table):
            head=pane.horizontalHeader()
            for visual,field in enumerate(f for f in saved.get('order',[]) if f in headers):head.moveSection(head.visualIndex(headers.index(field)),visual)
        p.apply_column_view()

    def mark_dirty(self):
        if self.controller.dirty:self.status.setText('Unsaved changes'); self.leads.reference_label.setText(self.controller.reference_summary())

    def save(self,checked=False,after=None):
        if self.busy:return
        controller=self.controller
        selected=[self.leads.proxy.mapToSource(i) for i in self.leads.table.selectionModel().selectedIndexes()]
        cells=[(i.row(),i.column()) for i in selected]
        def restore_selection():
            selection=QItemSelection()
            for row,column in cells:
                index=self.leads.proxy.mapFromSource(self.leads.model.index(row,column))
                if index.isValid():selection.select(index,index)
            self.leads.table.selectionModel().select(selection,QItemSelectionModel.SelectionFlag.ClearAndSelect)
        if controller.mode=='draft' and controller.sheet:
            sid=controller.sheet['id']; version=controller.sheet['version']; payload=controller.draft_payload()
            def done(result):
                controller.sheet['version']=result['version']; payload['row_ids']=result['row_ids']; controller.sheet['payload']=payload
                controller.dirty=False; self.leads.refresh(); restore_selection()
                self.save_conflict=False
                if after:after()
            self.run(lambda:self.client.call('sheet_save',sheet_id=sid,version=version,payload=payload),done,'Saving private draft…')
        elif controller.mode=='records' and controller.pending_edits():
            edits=controller.pending_edits()
            def done(rows):
                mapping={r['id']:r for r in rows}; controller.load_leads({'rows':[mapping.get(r['id'],r) for r in controller.lead_rows]}); self.leads.refresh()
                restore_selection(); self.save_conflict=False
                if after:after()
            self.run(lambda:self.client.call('bulk_edit',edits=edits),done,'Saving authorized changes…')
        elif after:after()

    def auto_save(self):
        if self.busy or self.save_conflict:return
        self.remember_view()
        if self.controller.mode=='draft' and self.controller.dirty:self.save()
        elif self.controller.settings_service.dirty:
            dirty=dict(self.controller.settings_service.dirty)
            self.run(lambda:[self.client.call('preferences',key=k,value=v,save=True) for k,v in dirty.items()],lambda _:[self.controller.settings_service.dirty.pop(k,None) for k in dirty],'Saving your preferences…')

    def rebuild_tabs(self):
        self.tabs.blockSignals(True)
        while self.tabs.count():self.tabs.removeTab(0)
        for sheet in self.sheet_rows:self.tabs.addTab(sheet['name'])
        self.tabs.blockSignals(False)

    def switch_sheet(self,index):
        if self.busy or index<0 or index>=len(self.sheet_rows):return
        self.with_saved(lambda:self.load_sheet(self.sheet_rows[index]['id']))

    def load_sheet(self,sid):
        def done(sheet):
            self.save_conflict=False
            self.controller.load_sheet(sheet); self.controller.settings_service.set('last_sheet_'+sheet['campaign_id'],sid)
            self.tabs.blockSignals(True); self.tabs.setCurrentIndex(next((i for i,s in enumerate(self.sheet_rows) if s['id']==sid),0)); self.tabs.blockSignals(False)
            self.leads.clear_filters(); self.leads.refresh(); self.restore_view(); self.status.setText('Private draft · Saved')
        self.run(lambda:self.client.call('sheet_load',sheet_id=sid),done,'Opening worksheet…')

    def new_sheet(self,checked=False,default=False):
        if self.busy or not self.campaign:return
        name,ok=('Sheet1',True) if default else QInputDialog.getText(self,'New worksheet','Sheet name:')
        if ok and name.strip():
            self.with_saved(lambda:self.run(lambda:self.client.call('sheet_create',campaign_id=self.campaign['campaign_id'],name=name.strip()),lambda result:self.reload_sheets(result['id']),'Creating worksheet…'))

    def reload_sheets(self,sid=None):
        def done(rows):
            self.sheet_rows=rows; self.rebuild_tabs()
            target=next((i for i,r in enumerate(rows) if r['id']==sid),0)
            if rows:
                self.tabs.blockSignals(True); self.tabs.setCurrentIndex(target); self.tabs.blockSignals(False); self.load_sheet(rows[target]['id'])
            else:self.controller._load([],[],[]); self.controller.sheet=None; self.leads.refresh()
        self.run(lambda:self.client.call('sheets',campaign_id=self.campaign['campaign_id']),done)

    def rename_sheet(self):
        if self.busy or not self.controller.sheet:return
        name,ok=QInputDialog.getText(self,'Rename worksheet','New name:',text=self.controller.sheet['name'])
        if ok:self.with_saved(lambda:self.run(lambda:self.client.call('sheet_rename',sheet_id=self.controller.sheet['id'],version=self.controller.sheet['version'],name=name),lambda _:self.reload_sheets(self.controller.sheet['id'])))

    def duplicate_sheet(self):
        if self.busy or not self.controller.sheet:return
        name,ok=QInputDialog.getText(self,'Duplicate worksheet','Copy name:',text=self.controller.sheet['name']+' copy')
        if ok:self.with_saved(lambda:self.run(lambda:self.client.call('sheet_create',campaign_id=self.campaign['campaign_id'],name=name,duplicate_id=self.controller.sheet['id']),lambda r:self.reload_sheets(r['id'])))

    def delete_sheet(self):
        sheet=self.controller.sheet
        if self.busy or not sheet:return
        if QMessageBox.question(self,'Delete worksheet','Archive this private sheet? Committed leads and their history will remain. Unsaved draft edits will be discarded.')!=QMessageBox.StandardButton.Yes:return
        self.run(lambda:self.client.call('sheet_delete',sheet_id=sheet['id'],version=sheet['version']),lambda _:self.reload_sheets())

    def refresh_records(self):
        if self.busy or not self.campaign:return
        def done(result):
            self.save_conflict=False
            self.total=result['total']; self.controller.load_leads(result); self.leads.refresh(); self.restore_view()
            self.paging.setText(f"{min(self.offset+1,self.total)}–{min(self.offset+len(result['rows']),self.total)} of {self.total:,}")
            self.previous.setEnabled(self.offset>0); self.next.setEnabled(self.offset+200<self.total)
        self.with_saved(lambda:self.run(lambda:self.client.call('leads',campaign_id=self.campaign['campaign_id'],view=self.view,archived=self.view=='archived',offset=self.offset,limit=200,search=self.query.text().strip()),done,'Loading authorized leads…'))

    def page(self,direction): self.with_saved(lambda:self._page(direction))
    def _page(self,direction): self.offset=max(0,self.offset+direction*200); self.refresh_records()

    def refresh_dashboard(self):
        if self.busy:return
        def done(rows):
            if self.campaign: rows=[r for r in rows if r['campaign_id']==self.campaign['campaign_id']]
            keys=['campaign_name','campaign_id','team_lead','allocation','start','end','total','qualified','disqualified','delivered','remaining','average','status']
            self.campaign_table.setRowCount(len(rows))
            for i,row in enumerate(rows):
                for j,key in enumerate(keys): self.campaign_table.setItem(i,j,QTableWidgetItem(str(row[key]) if row[key] is not None else 'Not set'))
            self.campaign_table.resizeColumnsToContents()
            self.charts.refresh([CampaignProgress(r['campaign_id'],r['campaign_name'],r['allocation'],parse_date(r['start']),parse_date(r['end']),r['total'],r['qualified'],r['disqualified'],r['delivered'],r['status']) for r in rows])
        self.run(lambda:self.client.call('dashboard'),done,'Loading campaign metrics…')

    def poll_notifications(self):
        if self.busy or getattr(self,'_polling',False):return
        self._polling=True; task=TeamTask(lambda:self.client.call('notifications')); self.poll_task=task
        def finish(result):
            self._polling=False
            if isinstance(result,dict):self.notification_button.setText(f"Notifications ({result['unread']})")
        task.signals.result.connect(finish); task.signals.error.connect(finish); QThreadPool.globalInstance().start(task)

    def sign_out(self):
        if self.busy:return
        self.with_saved(lambda:self.run(self.client.logout,lambda _:self._finish_close(),'Signing out…'))

    def _finish_close(self): self._closing=True; self.close()

    def closeEvent(self,event):
        if self._closing:
            self.autosave.stop(); self.poll.stop(); event.accept(); return
        if self.busy:event.ignore(); return
        if self.controller.dirty:
            event.ignore(); self.with_saved(lambda:self.run(self.client.logout,lambda _:self._finish_close())); return
        event.ignore(); self.run(self.client.logout,lambda _:self._finish_close())
