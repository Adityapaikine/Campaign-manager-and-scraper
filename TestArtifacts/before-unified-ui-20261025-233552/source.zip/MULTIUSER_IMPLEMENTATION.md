# Multi-user implementation and verification

Updated 25 October 2026. The existing PySide6 application now has an authenticated Team Workspace and a shared service on this PC. It reuses the grid, worksheet engine, validators, import mapping, formula engine, reference database connectors and campaign charts.

## Current deployment

- The service is running at http://127.0.0.1:8765 on this PC only. Schema 3 responds successfully; missing and invalid bearer tokens receive HTTP 401.
- The live database remains Data/LeadManager/cache/lead_manager.sqlite3. Additive migration/adoption preserved all 362 leads from two legacy workspaces, including one pre-existing duplicate. Historical owners remain unassigned for explicit Super User mapping.
- Original workspace file hashes match their pre-adoption hashes. Integrity and foreign-key checks passed. A historical general campaign preserves the previously unscoped worksheet.
- A consistent pre-adoption backup is Data/LeadManager/cache/before-adoption-20261025-184451.sqlite3. The original source/workspace and database backups are in TestArtifacts/before-multiuser-20261025-023319.
- No live user account or default password was created. Run **Setup Team Server.bat** to enter the initial Super User identity and private password. The service can remain running during setup.
- Adoption enabled the .team-mode marker. Normal startup opens Team Workspace. The preserved local scraper/research application uses a separate Data/LocalResearch draft area through **Start Local Research.vbs** or the account menu. Shared committed records are authoritative.

## Implemented behavior

### Identity, access and integrity

Accounts use Argon2id password hashes, expiring hashed sessions, login throttling, logout and revocation. Super User, Department Manager, Team Lead and Employee scopes are enforced by the service. Departments and reporting relationships are configurable; Operations, Quality, DBA and Delivery are seeded.

Campaign membership, original ownership, current assignment, department, Team Lead, field policies and workflow locks apply to reads, searches, counts, writes, histories, clipboard copies and exports. Hidden fields and formula results that could expose hidden inputs are redacted from draft reads and exports.

Transactions, unique normalized duplicate keys, idempotent commit requests and optimistic versions protect shared writes. Campaign-wide validation checks committed leads and private drafts without returning another user's matching record. Existing TAL, suppression and campaign-rule validators are reused. Possible matches require review; configured domain caps include existing records conservatively.

### Workflow and administration

The UI supports user/department/campaign administration, campaign packages and rule review, account/suppression lists, field policies, review transitions, manual/equal-workload/round-robin assignment, department transfers, rejection/rework reasons, original-department returns, archive/restore, attributed comments, notifications, transfer history and audit history.

Transfers retain the Lead ID and original owner. Receiving employees need explicit assignment. Sending supervisors retain monitoring access but cannot edit another department's work. Their outgoing records do not appear in their own incoming queue.

### Worksheets, formulas and lookup

Private campaign worksheets support create, rename, duplicate, archive, autosave, conflict detection and recovery copies. Duplication does not duplicate committed Lead IDs. Imports are mapped and staged before validation/commit. Accepted draft rows are removed in the same transaction that publishes them.

Existing formulas, arrow references, function dropdown, custom columns, undo/redo, fill, filters, sorting and frozen columns remain available. Shift+Space and Ctrl+Space respect filtered rows, hidden columns and text editors. Bulk selection survives saves. Undoing a saved column change marks the draft dirty again. Saved filters retain value lists and conditions by header. Preferences belong to the account.

Populate asks which columns and rows to fill every time. Prospect lookup uses Prospect LinkedIn Link; company lookup uses Company Website. The shared local source is restricted to permitted campaign leads. SQL Server/PostgreSQL retain explicit connection settings, read-only queries and header mapping using the user's credentials. Team email pattern finding uses the accessible worksheet; external research remains in the separate local area.

### Dashboard, reports and layout

Team Lead follows CID. The dashboard includes the requested allocation/date/lead/delivery columns and charts. Daily target is ceil(allocation / inclusive calendar days). A Super User can enter cumulative delivery; other roles see scoped workflow deliveries. Qualified totals retain leads as they advance through Delivery. Rework and pending validation require a fresh qualification.

Reports use distinct committed Lead IDs and cover workflow, validation, employee workload, departments, transfer volume, elapsed delivery time and creation-date quality cohorts. All six report tabs export after a fresh permission check, with an audit event. Date filters include the entire final day.

The shared shell removes duplicated headings/campaign controls. Filters fit on one row at the verified 1366 x 768 size, with more space for the lead grid and an automatically collapsed details panel. Synthetic previews are TestArtifacts/team-workspace.png, team-workspace-laptop.png and team-dashboard.png.

## Main changed files

| Area | Files |
| --- | --- |
| Database, authorization and API | app/team/schema.py, access.py, service.py, api.py, client.py |
| Business operations | app/team/admin.py, leads.py, sheets.py, workflow.py, reporting.py, research.py, packages.py |
| Migration and launch | app/team/legacy.py, mode.py, team_server.py, verify_team_migration.py, app/main.py, suite_bootstrap.py |
| Authenticated desktop | app/ui_qt/team_main.py, team_window.py, team_controller.py, team_actions.py, team_admin.py, dialogs/team_dialogs.py |
| Existing component integration | app/ui_qt/widgets/lead_table.py, pages/leads_page.py, pages/workspace_tools.py, pages/formula_tools.py, dialogs/lead_import_dialog.py, app/core/campaign_manager.py |
| Setup and packaging | requirements.txt, make_portable.py, Team Start/Stop/Status scripts, Start Local Research.vbs |
| Guidance | MULTIUSER_SETUP.md, USABILITY_GUIDE.md, FORMULAS_GUIDE.md |
| New tests | tests/test_team_service.py, test_team_integrity.py, test_team_ui.py, test_team_shortcuts.py, test_team_launch.py |

## Verification evidence

- Full suite: **212 passed**, including the existing 189 regression tests. Evidence: TestArtifacts/multiuser-regression.xml.
- Subsequent focused service/UI checks after the final permission and date-boundary fixes: **23 passed**. Evidence: TestArtifacts/team-integration.xml.
- Final compact UI, shortcut and launch/export checks: **6 passed**. Evidence: TestArtifacts/team-final-ui.xml. These overlap the full suite; counts are not additive.
- Existing-feature coverage includes formulas and arrow references, import/export, filters/sorting, lookup mapping, campaign rules/dashboard, worksheet persistence and Qt UI.
- portable_check.py --ui passed dependency, spreadsheet, formula and existing application-page checks; it reported **469 supported formula functions**. Changed-module syntax compilation passed.
- Copied-data migration and repeat: 362 records preserved, unchanged sources skipped, integrity/FKs passed. Evidence: TestArtifacts/migration-copy-20261025-183703/result.json.
- Live adoption and source-file preservation: TestArtifacts/live-adoption-result.json.
- Live health, denied unauthenticated/invalid-token requests and verified Stop/Start: TestArtifacts/team-live-service.json. The stop script handles the Windows virtual environment's Python child process as well as its launcher.
- Synthetic visual checks passed at 1540 x 940 and 1366 x 768, without accessing live records.
- One non-failing warning remains: Starlette's test client deprecates the current httpx adapter in favor of httpx2.

## Setup still required and explicit limits

1. Create the initial Super User locally, then create staff, assign campaigns and map historical ownership. Do not post passwords in chat.
2. Other PCs require the server's intended DNS/IP, a trusted HTTPS certificate and suitable LAN/VPN/firewall access. Remote-device access is not configured or tested; the listener is loopback only.
3. Automatic restart after Windows reboot/logoff is not installed. Start/Stop/Status controls were verified in this session.
4. No real SQL Server/PostgreSQL endpoint or credentials were supplied. Connector regression tests cover mapping/query behavior; connection to the user's server is not verified.
5. Formula support is the existing 469-function engine, not every Excel feature. VBA, external-workbook links, dynamic spill output, INDIRECT and OFFSET are unsupported. Shared committed records and Team exports contain values; private sheets preserve formulas.
6. Private drafts are bounded at 5,000 rows / 12 MB; shared views page 200 rows. Cancel discards read/preview results when the active read finishes. Bulk writes complete transactionally. Unsaved edits cannot survive a crash before autosave; failed saves preserve edits in memory and offer recovery once connected.
7. No self-contained portable build was generated. Bundled Chromium/Qwen assets are absent from this checkout; the existing builder requires its runtime prerequisites. Source execution and Qt pages were checked on this PC. Employees must receive clean clients, never the server's Data, backups or logs.

See **MULTIUSER_SETUP.md** for setup, workflow definitions, external references, TLS, backup and rollback. Remote readiness and first-account provisioning are not represented as complete.
