"""Run on the trusted server PC only. Never distribute its Data folder."""
import argparse
import getpass
from pathlib import Path
from suite_bootstrap import configure
configure()

def main():
    from app.utils.config import DB_PATH
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['setup','serve','check','adopt-legacy','backup'])
    parser.add_argument('--database',type=Path,default=DB_PATH)
    parser.add_argument('--host',default='127.0.0.1'); parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--cert'); parser.add_argument('--key')
    parser.add_argument('--workspace-folder',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.command=='serve':
        if args.host not in ('127.0.0.1','localhost','::1') and not (args.cert and args.key):
            parser.error('Remote access requires --cert and --key. Keep the database on this PC and restrict its folder access.')
        import uvicorn
        from app.team.api import create_app
        uvicorn.run(create_app(args.database),host=args.host,port=args.port,ssl_certfile=args.cert,ssl_keyfile=args.key,
                    access_log=False,limit_concurrency=50,timeout_keep_alive=5)
    else:
        from app.team.service import Service
        from app.team.schema import transaction
        if args.command=='backup':
            from app.team.legacy import backup_database
            if not args.output:parser.error('Supply --output with a new backup filename.')
            print(backup_database(args.database,args.output))
        elif args.command=='adopt-legacy':
            from app.team.legacy import adopt_workspaces,backup_database
            from app.utils.config import DATA_DIR
            from datetime import datetime
            backup_database(args.database,args.database.with_name('before-adoption-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'.sqlite3'))
            print(adopt_workspaces(args.database,args.workspace_folder or DATA_DIR/'workspaces'))
            from app.team.mode import enable_shared_mode
            enable_shared_mode(args.database)
            print('Default launch now opens Team Workspace. Local research remains available in its separate data folder.')
        elif args.command=='setup':
            service=Service(args.database)
            name=input('Super User full name: ').strip(); username=input('Username: ').strip(); email=input('Email: ').strip()
            password=getpass.getpass('Password (at least 12 characters): ')
            if getpass.getpass('Confirm password: ')!=password: raise SystemExit('Passwords did not match. No account created.')
            service.bootstrap(name,username,email,password)
            from app.team.mode import enable_shared_mode
            enable_shared_mode(args.database)
            print('Super User created. Start the server, then sign in through Team Workspace.')
        else:
            Service(args.database)
            with transaction(args.database,False) as db:
                print('Integrity:',db.execute('PRAGMA integrity_check').fetchone()[0])
                print('Provisioned:',bool(db.execute('SELECT 1 FROM team_users').fetchone()))
                print('Schema:',db.execute('SELECT max(version) FROM team_migrations').fetchone()[0])

if __name__=='__main__': main()
