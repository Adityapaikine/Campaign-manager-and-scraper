# Lead Workspace: everyday controls

Restart the portable application after this update. Work directly from this folder; keep its `Data` folder when copying your working application to another PC.

## Redesigned workspace

The light blue interface follows the supplied CRM reference. Use **Leads Workspace** in the sidebar or **Ctrl+2**. Your current display preferences are set to Light, Professional Blue, and Lead overview; the settings page still offers the other themes.

**Lead overview** shows the existing campaign, agent, phone, disposition, and comment columns. **All columns** restores the complete worksheet. The spreadsheet continues to scroll, edit, copy, and paste as before; no pagination limits the rows available to these operations.

Select a lead to see its **Lead details** panel. Overview shows contact information, disposition, and comment; Validation and Notes show the corresponding existing data. **Edit lead** opens a form with **Save changes** and **Cancel**. Saved edits form one Undo operation and mark affected leads for revalidation. **Edit notes** opens the same form at Notes. Blank entry rows do not enable saved-lead actions.

The details panel collapses automatically on narrower windows. Use **Details** to reopen it or the navigation toggle to create more room. The table keeps horizontal scrolling when fewer columns fit.

Use **Import leads**, **Export**, and the adjacent more-actions menu for import, export, paste, save working copy, and new worksheet. The existing Add data, Reference lists, Validate, Rows, Find emails, and Summary controls remain available.

## Choose a workspace

Use **Workspace** above the lead grid to open General workspace or a campaign imported through Campaign Manager. Activating a campaign opens its worksheet. Each workspace keeps its own leads, custom columns, TAL, suppression, validation results and matching/email-search preferences. The previous worksheet is saved before switching. The last active workspace reopens when the application starts.

Switching workspaces does not move existing leads. Import, paste or transfer Scraper results into the intended workspace. General workspace preserves leads that are not attached to a campaign. The initial upgrade preserves previously uploaded reference lists; existing checkpoint recovery remains available when no saved worksheet exists yet.

## Filter any column

Click the dropdown at the right of its header, right-click the header, or press **Alt+Down** while a cell in that column has focus.

- Search the available values, then tick the values to keep. **Select All** and **Select None** apply to the visible search results. An empty selection displays no rows; **Clear filter from this column** removes the restriction.
- Select **(Blanks)** to show missing values. A literal value named `(Blanks)` remains distinct from an empty cell.
- Sort ascending or descending. Numeric values sort numerically.
- Use text conditions such as Contains, Equals, Begins with and Ends with; Equals supports `*` and `?` wildcards. Number/date filters support comparisons. Dates accept `DD-MMM-YYYY`, `YYYY-MM-DD` and day/month/year formats.
- Filters across columns combine. Available values account for the other filters. A funnel marks each filtered header, and the toolbar lists active column filters, including filters on hidden columns.

**Reset** resets column conditions, selected values, search and status filtering. Sorting alone does not change worksheet values. Exports of **Currently filtered rows** preserve the displayed row order.

## Choose columns and freeze identity fields

Select **Lead overview**, **Research**, **Email Finding**, **QA Review**, or **All columns** from View. **Columns** lets you name a custom selection of columns and choose whether to freeze identity fields. The last view and column widths are remembered.

**Freeze identity** keeps First Name, Last Name and Company Name beside the scrolling data. Both panes share row selection, filtering and vertical scrolling. All columns remain in exports. Pasting into a reduced view fills its visible columns; select All columns and turn off freezing before pasting an entire worksheet layout.

## Edit and correct mistakes

Use **Undo / Redo**, **Ctrl+Z / Ctrl+Y** to reverse cell edits, a whole paste or cleared cells. An undone paste removes rows that it added. History is for the current editing session and resets when importing, starting a new worksheet, changing reference lists or switching workspaces.

QA Status and Primary Reason are calculated fields. Editing lead details marks affected rows **Needs validation** and removes outdated QA conclusions. Related duplicate rows are also marked when identifiers change. Revalidate before exporting those rows as Qualified or Disqualified.

## Import without repeating column mapping

Successful lead, TAL and suppression imports remember the column mapping for that source layout, including ignored columns. The next matching layout displays the saved mapping for review. You can change it, disable **Remember this column layout**, or choose **Reset to automatic mapping**. Empty worksheets cannot be imported; select the populated sheet.

## Validate and review

**Validate** checks the whole worksheet. The **Rows** menu checks selected rows or edited/unfinished rows. Selection follows the underlying leads even after sorting and filtering. Related duplicates are included; active campaign domain caps require checking the entire worksheet to keep the result correct. Cancel preserves completed results and leaves remaining rows available for validation.

The existing exclusion rules remain:

| Condition | QA Status | Primary Reason |
| --- | --- | --- |
| No TAL match | Disqualified | Tal not Mapped |
| Confirmed suppression match | Disqualified | Suppression matched |

Suppression takes priority when both conditions apply. Possible fuzzy matches remain Manual Review.

**Summary** opens the review panel. QA Review also opens it when selecting a problem row. It shows the source list, matching explanation and suggested next step. Use **Go to field**, **Recheck row**, and **Next issue** to work through the visible leads.

## Manage reference lists

To fill lead fields from saved leads, click **Populate from database** in the workspace heading. Choose the destination columns each time and select the lead scope. Prospect details match on **Prospect LinkedIn Link**; company details match on **Company Website**. Existing values are kept unless replacement is enabled. Missing matches and conflicting saved values are skipped. Use **Ctrl+Z** to undo a population. To use SQL Server or PostgreSQL, open **Settings → Database** or the arrow beside **Populate from database**, enter the connection details, and review the column mapping. See [DATABASE_LOOKUP_GUIDE.md](DATABASE_LOOKUP_GUIDE.md) for the complete field mapping, external connection setup, and instructions for adding local reference data.

Choose **Reference lists → Manage saved lists…** to see the saved source, row count and upload time. Search its preview, upload a replacement, or remove the uploaded list. The preview displays up to 500 matching rows; validation uses every saved row.

Manual lists override the corresponding campaign reference within that workspace. Removing a manual upload restores campaign references when present. Removed files are retained in the workspace's reference archive. Every affected lead is marked for validation again.

## Calculate with formulas

Use the compact **ƒx Formulas** dropdown and formula bar above the lead grid. Enter expressions such as `=[Revenue]*10%`, `=SUM(A1:A10)` or `=column1+column2`. Press **Shift+F3** to browse functions, **Ctrl+Shift+F** to edit in the formula bar, **Ctrl+D** to fill a selection down and **F9** to recalculate. Add custom columns with **Add columns** and remove them with **Formulas → Delete custom columns**; both actions support Undo. See [FORMULAS_GUIDE.md](FORMULAS_GUIDE.md) for examples, all shortcuts, saving/export behavior and compatibility limits.

## Export exactly the rows needed

Export offers **All leads**, **Qualified only**, **Disqualified only** and **Currently filtered rows**, with counts before saving. Qualified means Valid or Valid - Email Generated. Rows awaiting validation are excluded from Qualified and Disqualified exports. The Lead Data and Validation Details sheets contain the same selected rows. All worksheet columns are included regardless of the current column view.
