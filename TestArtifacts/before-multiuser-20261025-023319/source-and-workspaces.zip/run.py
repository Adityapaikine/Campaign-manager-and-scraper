import sys
from suite_bootstrap import configure
configure()

if __name__ == "__main__":
    if "--check" in sys.argv:
        import Scraper
        from app.ui_qt.main_window import MainWindow
        from app.constants import STANDARD_HEADERS
        assert list(STANDARD_HEADERS) == Scraper.HEADERS
        print("Lead Workspace is ready. Scraper v" + Scraper.APP_VERSION + "; Lead Manager integration loaded.")
    else:
        from app.main import main
        main()
