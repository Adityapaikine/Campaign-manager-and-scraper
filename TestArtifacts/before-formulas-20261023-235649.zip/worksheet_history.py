"""Cell-level undo history. Large worksheets are not copied on each keystroke."""
from dataclasses import dataclass


@dataclass
class CellEdit:
    label: str
    before: dict
    after: dict
    previous_count: int


class WorksheetHistory:
    def __init__(self):
        self.undo_stack = []
        self.redo_stack = []

    def clear(self):
        self.undo_stack.clear()
        self.redo_stack.clear()

    def push(self, command):
        self.undo_stack.append(command)
        self.redo_stack.clear()
        # Bound history by changed cells as well as command count.
        while len(self.undo_stack) > 1 and (len(self.undo_stack) > 100 or sum(len(c.before) for c in self.undo_stack) > 250000):
            self.undo_stack.pop(0)

